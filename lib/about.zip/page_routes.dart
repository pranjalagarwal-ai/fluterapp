class pageRoutes {
  static String homeRoute = '/secondaryhomepage';
}
